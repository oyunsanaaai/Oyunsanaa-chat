const openBtn = document.getElementById('openChatBtn');
const closeBtn = document.getElementById('closeChatBtn');
const chatContainer = document.getElementById('chatContainer');
const chatbox = document.getElementById('chatbox');
const userInput = document.getElementById('userInput');

openBtn.addEventListener('click', () => {
  chatContainer.classList.remove('hidden');
  openBtn.style.display = 'none';
  userInput.focus();
});

closeBtn.addEventListener('click', () => {
  chatContainer.classList.add('hidden');
  openBtn.style.display = 'block';
});

userInput.addEventListener('keypress', function (e) {
  if (e.key === 'Enter') {
    const message = userInput.value.trim();
    if (message) {
      appendMessage('user', message);
      getBotResponse(message);
      userInput.value = '';
    }
  }
});

function appendMessage(sender, text) {
  const msg = document.createElement('div');
  msg.className = `message ${sender}`;
  msg.textContent = sender === 'user' ? `Та: ${text}` : `Oyunsanaa: ${text}`;
  chatbox.appendChild(msg);
  chatbox.scrollTop = chatbox.scrollHeight;
}

function getBotResponse(input) {
  let response = '';

  if (input.toLowerCase().includes('сайн')) {
    response = 'Сайн уу, тантай уулзсандаа баяртай байна!';
  } else {
    response = 'Би ойлголоо, үргэлжлүүлэн ярилцъя.';
  }

  appendMessage('bot', response);
}
